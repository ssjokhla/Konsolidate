#!/bin/bash

php /var/Konsolidate/Categories/Deployment/depRabbitMQServer.php & php /var/Konsolidate/Categories/Deployment/pushRabbitMQServer.php
